%-----------------------------------------------------------------------
% Job saved on 25-Mar-2019 10:17:49 by cfg_util (rev $Rev: 6942 $)
% spm SPM - SPM12 (7219)
% cfg_basicio BasicIO - Unknown
%-----------------------------------------------------------------------
%%
matlabbatch{1}.spm.tools.dartel.warp.images = {
                                               {
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/08/t1/rc1sub08_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/09/t1/rc1sub09_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/10/t1/rc1sub10_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/11/t1/rc1sub11_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/12/t1/rc1sub12_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/13/t1/rc1sub13_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/14/t1/rc1sub14_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/15/t1/rc1sub15_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/16/t1/rc1sub16_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/17/t1/rc1sub17_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/18/t1/rc1sub18_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/61/t1/rc1sub61_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/62/t1/rc1sub62_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/63/t1/rc1sub63_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/64/t1/rc1sub64_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/65/t1/rc1sub65_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/66/t1/rc1sub66_t1-0001.nii,1'
                                               }
                                               {
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/08/t1/rc2sub08_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/09/t1/rc2sub09_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/10/t1/rc2sub10_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/11/t1/rc2sub11_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/12/t1/rc2sub12_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/13/t1/rc2sub13_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/14/t1/rc2sub14_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/15/t1/rc2sub15_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/16/t1/rc2sub16_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/17/t1/rc2sub17_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/18/t1/rc2sub18_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/61/t1/rc2sub61_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/62/t1/rc2sub62_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/63/t1/rc2sub63_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/64/t1/rc2sub64_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/65/t1/rc2sub65_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/66/t1/rc2sub66_t1-0001.nii,1'
                                               }
                                               {
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/08/t1/rc3sub08_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/09/t1/rc3sub09_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/10/t1/rc3sub10_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/11/t1/rc3sub11_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/12/t1/rc3sub12_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/13/t1/rc3sub13_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/14/t1/rc3sub14_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/15/t1/rc3sub15_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/16/t1/rc3sub16_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/17/t1/rc3sub17_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/18/t1/rc3sub18_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/61/t1/rc3sub61_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/62/t1/rc3sub62_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/63/t1/rc3sub63_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/64/t1/rc3sub64_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/65/t1/rc3sub65_t1-0001.nii,1'
                                               '/home/feng/Downloads/basicfMRI/1_Data_new/66/t1/rc3sub66_t1-0001.nii,1'
                                               }
                                               }';
%%
matlabbatch{1}.spm.tools.dartel.warp.settings.template = 'Template';
matlabbatch{1}.spm.tools.dartel.warp.settings.rform = 0;
matlabbatch{1}.spm.tools.dartel.warp.settings.param(1).its = 3;
matlabbatch{1}.spm.tools.dartel.warp.settings.param(1).rparam = [4 2 1e-06];
matlabbatch{1}.spm.tools.dartel.warp.settings.param(1).K = 0;
matlabbatch{1}.spm.tools.dartel.warp.settings.param(1).slam = 16;
matlabbatch{1}.spm.tools.dartel.warp.settings.param(2).its = 3;
matlabbatch{1}.spm.tools.dartel.warp.settings.param(2).rparam = [2 1 1e-06];
matlabbatch{1}.spm.tools.dartel.warp.settings.param(2).K = 0;
matlabbatch{1}.spm.tools.dartel.warp.settings.param(2).slam = 8;
matlabbatch{1}.spm.tools.dartel.warp.settings.param(3).its = 3;
matlabbatch{1}.spm.tools.dartel.warp.settings.param(3).rparam = [1 0.5 1e-06];
matlabbatch{1}.spm.tools.dartel.warp.settings.param(3).K = 1;
matlabbatch{1}.spm.tools.dartel.warp.settings.param(3).slam = 4;
matlabbatch{1}.spm.tools.dartel.warp.settings.param(4).its = 3;
matlabbatch{1}.spm.tools.dartel.warp.settings.param(4).rparam = [0.5 0.25 1e-06];
matlabbatch{1}.spm.tools.dartel.warp.settings.param(4).K = 2;
matlabbatch{1}.spm.tools.dartel.warp.settings.param(4).slam = 2;
matlabbatch{1}.spm.tools.dartel.warp.settings.param(5).its = 3;
matlabbatch{1}.spm.tools.dartel.warp.settings.param(5).rparam = [0.25 0.125 1e-06];
matlabbatch{1}.spm.tools.dartel.warp.settings.param(5).K = 4;
matlabbatch{1}.spm.tools.dartel.warp.settings.param(5).slam = 1;
matlabbatch{1}.spm.tools.dartel.warp.settings.param(6).its = 3;
matlabbatch{1}.spm.tools.dartel.warp.settings.param(6).rparam = [0.25 0.125 1e-06];
matlabbatch{1}.spm.tools.dartel.warp.settings.param(6).K = 6;
matlabbatch{1}.spm.tools.dartel.warp.settings.param(6).slam = 0.5;
matlabbatch{1}.spm.tools.dartel.warp.settings.optim.lmreg = 0.01;
matlabbatch{1}.spm.tools.dartel.warp.settings.optim.cyc = 3;
matlabbatch{1}.spm.tools.dartel.warp.settings.optim.its = 3;
